from django.db import models
class CurrentDateTime(models.Model):
    current_date_time = models.DateTimeField(auto_now_add=True)