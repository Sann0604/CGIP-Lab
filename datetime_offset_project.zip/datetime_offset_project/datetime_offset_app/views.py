from django.shortcuts import render
from datetime import datetime, timedelta
from .models import CurrentDateTime
def datetime_view(request):
    # Get the current date time from the server
    current_datetime = datetime.now()
    # Save the current datetime to the database
    CurrentDateTime.objects.create(current_date_time=current_datetime)
    # Calculate the future datetime (four hours ahead)
    future_datetime = current_datetime + timedelta(hours=4)
    # Calculate the past datetime (four hours before)
    past_datetime = current_datetime - timedelta(hours=4)
    context = {
    'current_date_time': current_datetime,
    'future_datetime': future_datetime,
    'past_datetime': past_datetime,
    }
    return render(request, 'datetime_offset_app/datetime.html', context)