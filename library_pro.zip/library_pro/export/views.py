import csv
from django.http import HttpResponse
from django.shortcuts import get_object_or_404
from catalog.models import Book, Author, Genre
from reportlab.lib.pagesizes import letter
from reportlab.pdfgen import canvas

def export_books_csv(request):
    # Create the HttpResponse object with the appropriate CSV header.
    response = HttpResponse(content_type='text/csv')
    response['Content-Disposition'] = 'attachment; filename="books.csv"'

    writer = csv.writer(response)
    writer.writerow(['Title', 'Author', 'Summary', 'ISBN', 'Genres'])

    books = Book.objects.all()
    for book in books:
        genres = ", ".join([genre.name for genre in book.genre.all()])
        writer.writerow([book.title, book.author, book.summary, book.isbn, genres])

    return response

def export_books_pdf(request):
    # Create the HttpResponse object with the appropriate PDF header.
    response = HttpResponse(content_type='application/pdf')
    response['Content-Disposition'] = 'attachment; filename="books.pdf"'

    # Create the PDF object, using the response object as its "file."
    p = canvas.Canvas(response, pagesize=letter)
    p.drawString(100, 750, "Books List")
    
    books = Book.objects.all()
    y = 700
    for book in books:
        genres = ", ".join([genre.name for genre in book.genre.all()])
        p.drawString(100, y, f"Title: {book.title}")
        p.drawString(100, y-20, f"Author: {book.author}")
        p.drawString(100, y-40, f"Summary: {book.summary}")
        p.drawString(100, y-60, f"ISBN: {book.isbn}")
        p.drawString(100, y-80, f"Genres: {genres}")
        y -= 100
        if y < 100:
            p.showPage()
            y = 750

    p.showPage()
    p.save()
    return response
