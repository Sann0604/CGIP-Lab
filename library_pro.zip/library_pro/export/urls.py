from django.urls import path
from . import views

urlpatterns = [
    path('export/csv/', views.export_books_csv, name='export_books_csv'),
    path('export/pdf/', views.export_books_pdf, name='export_books_pdf'),
]
