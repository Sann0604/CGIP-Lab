from django.shortcuts import render, get_object_or_404
from .models import Book, Author, Genre

def index(request):
    books = Book.objects.all()
    authors = Author.objects.all()
    genres = Genre.objects.all()

    return render(
        request,
        'catalog/index.html',
        context={
            'books': books,
            'authors': authors,
            'genres': genres,
        },
    )

def book_detail_view(request, pk):
    book = get_object_or_404(Book, pk=pk)
    return render(request, 'catalog/book_detail.html', context={'book': book})
