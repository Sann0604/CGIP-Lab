from django.contrib import admin

from .models import course,stud

# Register your models here.
admin.site.register(stud)
admin.site.register(course)
