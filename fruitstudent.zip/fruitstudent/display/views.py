from django.shortcuts import render

def index(request):
    fruits = ["Apple", "Banana", "Cherry", "Date", "Fig"]
    students = ["John Doe", "Jane Smith", "Emily Davis", "Michael Brown", "Jessica Wilson"]
    context = {
        'fruits': fruits,
        'students': students
    }
    return render(request, 'display/index.html', context)
