import pygame
import math
import webbrowser
import random

# Initialize Pygame
pygame.init()

# Screen dimensions
screen_width = 800
screen_height = 600

# Colors
black = (0, 0, 0)
yellow = (255, 255, 0)
grey = (192, 192, 192)
blue = (0, 0, 255)
red = (255, 0, 0)
orange = (255, 165, 0)
brown = (139, 69, 19)
green = (0, 255, 0)
white = (255, 255, 255)

# Screen setup
screen = pygame.display.set_mode((screen_width, screen_height))
pygame.display.set_caption("Solar System Animation & Quiz")

# Sun settings
sun_radius = 50

# Planet settings with different speeds
planets = [
    {"name": "Mercury", "color": grey, "radius": 10, "orbit_radius": 60, "speed": 0.05,
     "info": "Mercury is the closest planet to the Sun.\n\nWikipedia: https://en.wikipedia.org/wiki/Mercury_(planet)"},
    {"name": "Venus", "color": yellow, "radius": 20, "orbit_radius": 100, "speed": 0.03,
     "info": "Venus is known for its thick atmosphere and high temperatures.\n\nWikipedia: https://en.wikipedia.org/wiki/Venus"},
    {"name": "Earth", "color": blue, "radius": 25, "orbit_radius": 150, "speed": 0.02,
     "info": "Earth is our home planet and the only one known to support life.\n\nWikipedia: https://en.wikipedia.org/wiki/Earth"},
    {"name": "Mars", "color": red, "radius": 20, "orbit_radius": 200, "speed": 0.015,
     "info": "Mars is known as the Red Planet due to iron oxide on its surface.\n\nWikipedia: https://en.wikipedia.org/wiki/Mars"},
    {"name": "Jupiter", "color": orange, "radius": 40, "orbit_radius": 250, "speed": 0.01,
     "info": "Jupiter is the largest planet in our solar system.\n\nWikipedia: https://en.wikipedia.org/wiki/Jupiter"},
    {"name": "Saturn", "color": brown, "radius": 35, "orbit_radius": 300, "speed": 0.008,
     "info": "Saturn is famous for its stunning ring system.\n\nWikipedia: https://en.wikipedia.org/wiki/Saturn"},
    {"name": "Uranus", "color": green, "radius": 30, "orbit_radius": 350, "speed": 0.005,
     "info": "Uranus has a unique tilt, rotating on its side.\n\nWikipedia: https://en.wikipedia.org/wiki/Uranus"}
]

# Original speeds for reset
original_speeds = {planet["name"]: planet["speed"] for planet in planets}

# Animation state
animation_running = True
selected_planet = None
info_visible = False
quiz_mode = False
score = 0
selected_choice = None

# Questions and answers
questions = [
    {"question": "Which planet is known for its rings?", "choices": ["Jupiter", "Saturn", "Uranus"], "answer": "Saturn"},
    {"question": "Which planet is the closest to the Sun?", "choices": ["Mercury", "Venus", "Earth"], "answer": "Mercury"},
    {"question": "Which planet is known as the Red Planet?", "choices": ["Mars", "Earth", "Venus"], "answer": "Mars"},
    {"question": "Which planet has the largest radius?", "choices": ["Jupiter", "Saturn", "Uranus"], "answer": "Jupiter"},
    {"question": "Which planet rotates on its side?", "choices": ["Uranus", "Venus", "Earth"], "answer": "Uranus"}
]

# Randomly select a question
current_question = random.choice(questions)

def draw_sun():
    pygame.draw.circle(screen, yellow, (screen_width // 2, screen_height // 2), sun_radius)

def draw_orbits():
    for planet in planets:
        pygame.draw.circle(screen, white, (screen_width // 2, screen_height // 2), planet["orbit_radius"], 1)

def draw_planets(angle):
    global selected_planet
    for planet in planets:
        x = int(screen_width // 2 + planet["orbit_radius"] * math.cos(angle * planet["speed"]))
        y = int(screen_height // 2 + planet["orbit_radius"] * math.sin(angle * planet["speed"]))
        pygame.draw.circle(screen, planet["color"], (x, y), planet["radius"])
        
        # Draw planet names
        font = pygame.font.Font(None, 24)
        text = font.render(planet["name"], True, white)
        screen.blit(text, (x - text.get_width() // 2, y - text.get_height() // 2))

        # Check for click on planet
        if pygame.mouse.get_pressed()[0]:
            mouse_x, mouse_y = pygame.mouse.get_pos()
            if (x - mouse_x)**2 + (y - mouse_y)**2 <= planet["radius"]**2:
                selected_planet = planet
                return

def draw_info_box():
    if selected_planet and info_visible:
        info_font = pygame.font.Font(None, 24)
        info_lines = selected_planet["info"].split("\n")
        box_width = max(max(info_font.size(line)[0] for line in info_lines), 300)
        box_height = sum(info_font.size(line)[1] for line in info_lines) + 20
        box_x = (screen_width - box_width) // 2
        box_y = (screen_height - box_height) // 2

        pygame.draw.rect(screen, black, (box_x, box_y, box_width, box_height))
        pygame.draw.rect(screen, white, (box_x, box_y, box_width, box_height), 2)

        for i, line in enumerate(info_lines):
            label = info_font.render(line, True, white)
            screen.blit(label, (box_x + 10, box_y + 10 + i * info_font.size(line)[1]))

        # Handle link clicking
        if pygame.mouse.get_pressed()[0]:
            mouse_x, mouse_y = pygame.mouse.get_pos()
            if (box_x < mouse_x < box_x + box_width) and (box_y < mouse_y < box_y + box_height):
                webbrowser.open(selected_planet["info"].split("Wikipedia: ")[1].strip())

def draw_quiz():
    global quiz_mode
    font = pygame.font.Font(None, 36)
    choice_font = pygame.font.Font(None, 28)
    
    question_text = font.render(current_question["question"], True, white)
    screen.blit(question_text, (50, 50))
    
    choices = current_question["choices"]
    for i, choice in enumerate(choices):
        choice_text = choice_font.render(f"{i + 1}. {choice}", True, white)
        screen.blit(choice_text, (50, 100 + i * 40))
    
    # Displaying score
    score_text = font.render(f"Score: {score}", True, white)
    screen.blit(score_text, (screen_width - 150, 50))

def check_quiz_answer(selected_choice):
    global score, quiz_mode
    correct_answer = current_question["answer"]
    if selected_choice == correct_answer:
        score += 1
    quiz_mode = False

# Main loop
running = True
clock = pygame.time.Clock()
angle = 0

while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        elif event.type == pygame.KEYDOWN:
            if event.key == pygame.K_SPACE:
                animation_running = not animation_running
            elif event.key == pygame.K_UP:
                for planet in planets:
                    planet["speed"] = min(0.1, planet["speed"] + 0.001)
            elif event.key == pygame.K_DOWN:
                for planet in planets:
                    planet["speed"] = max(0.001, planet["speed"] - 0.001)
            elif event.key == pygame.K_r:
                for planet in planets:
                    planet["speed"] = original_speeds[planet["name"]]
            elif event.key == pygame.K_q:
                quiz_mode = not quiz_mode
                if quiz_mode:
                    # Randomly select a new question when quiz starts
                    current_question = random.choice(questions)
            elif event.key == pygame.K_1:
                if quiz_mode:
                    check_quiz_answer(current_question["choices"][0])
            elif event.key == pygame.K_2:
                if quiz_mode:
                    check_quiz_answer(current_question["choices"][1])
            elif event.key == pygame.K_3:
                if quiz_mode:
                    check_quiz_answer(current_question["choices"][2])
            elif event.key == pygame.K_i:
                info_visible = not info_visible

    if animation_running:
        screen.fill(black)
        draw_sun()
        draw_orbits()
        draw_planets(angle)
        if selected_planet:
            draw_info_box()
        angle += 0.01

    if quiz_mode:
        screen.fill(black)
        draw_quiz()

    pygame.display.flip()
    clock.tick(60)

pygame.quit()
