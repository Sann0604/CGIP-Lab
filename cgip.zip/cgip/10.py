import cv2
# Read the image
image_path = "Shinchan.jpg"
image = cv2.imread(image_path)
if image is None:
 print("Failed to load the image.")
else:
 cv2.imshow("Original Image", image)
 blur_kernel_size = (5, 5)
 blurred_image = cv2.blur(image, blur_kernel_size)
 cv2.imshow("Blurred Image", blurred_image)
 gaussian_blur_kernel_size = (5, 5)
 gaussian_blurred_image = cv2.GaussianBlur(image, gaussian_blur_kernel_size,0)
 cv2.imshow("Gaussian Blurred Image", gaussian_blurred_image)
 median_blur_kernel_size = 5 
 median_blurred_image = cv2.medianBlur(image, median_blur_kernel_size)
 cv2.imshow("Median Blurred Image", median_blurred_image)
 cv2.waitKey(0)
 cv2.destroyAllWindows()