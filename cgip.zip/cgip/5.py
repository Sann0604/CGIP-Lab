import pygame
from pygame.locals import *
from OpenGL.GL import *
from OpenGL.GLU import *
import numpy as np
def setColorForVertex(vertex):
    x, y, z = vertex
    if x >= 0 and y >= 0:
        glColor3f(1, 0, 0)
    elif x < 0 and y >= 0:
        glColor3f(0, 1, 0)
    elif x < 0 and y < 0:
        glColor3f(0, 0, 1)
    else:
        glColor3f(1, 1, 0)
def drawColoredSphere(radius, slices, stacks):
    for i in range(stacks):
        lat0 = np.pi * (-0.5 + float(i) / stacks) 
        z0 = np.sin(lat0)
        zr0 = np.cos(lat0)
        lat1 = np.pi * (-0.5 + float(i + 1) / stacks)
        z1 = np.sin(lat1) 
        zr1 = np.cos(lat1) 
        glBegin(GL_QUAD_STRIP)
        for j in range(slices + 1):
            lng = 2 * np.pi * float(j) / slices
            x = np.cos(lng)
            y = np.sin(lng)
            setColorForVertex((x * zr0, y * zr0, z0))
            glVertex3f(x * zr0 * radius, y * zr0 * radius, z0 * radius)
            setColorForVertex((x * zr1, y * zr1, z1))
            glVertex3f(x * zr1 * radius, y * zr1 * radius, z1 * radius)
        glEnd()
def main():
    pygame.init()
    display = (800, 600)
    pygame.display.set_mode(display, DOUBLEBUF | OPENGL)
    glEnable(GL_DEPTH_TEST)
    gluPerspective(45, (display[0] / display[1]), 0.1, 50.0)
    glTranslatef(0.0, 0.0, -5)
    clock = pygame.time.Clock()
    translate = [0, 0, 0]
    rotate = [0, 0, 0]
    scale = 1
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
        keys = pygame.key.get_pressed()
        if keys[pygame.K_LEFT]:
            translate[0] -= 0.05
        if keys[pygame.K_RIGHT]:
            translate[0] += 0.05
        if keys[pygame.K_UP]:
            translate[1] += 0.05
        if keys[pygame.K_DOWN]:
            translate[1] -= 0.05
        if keys[pygame.K_x]:
            rotate[0] += 3
        if keys[pygame.K_z]:
            rotate[2] += 3
        if keys[pygame.K_y]:
            rotate[1] += 3
        if keys[pygame.K_w]:
            scale += 0.05
        if keys[pygame.K_s]:
            scale -= 0.05
        if scale < 0.05:
            scale = 0.
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT)
        glPushMatrix()
        glTranslatef(*translate)
        glScalef(scale, scale, scale)
        glRotatef(rotate[0], 1, 0, 0)
        glRotatef(rotate[1], 0, 1, 0)
        glRotatef(rotate[2], 0, 0, 1)
        drawColoredSphere(1, 50, 50)
        glPopMatrix()
        pygame.display.flip()
        clock.tick(60)
if __name__ == "__main__":
    main()
