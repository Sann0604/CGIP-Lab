import pygame
import sys

def main():
    # Initialize Pygame
    pygame.init()
        
    # Screen dimensions
    screen_width = 800
    screen_height = 600

    # Colors
    black = (0, 0, 0)
    white = (255, 255, 255)
    red = (255, 0, 0)

    # Ball properties
    ball_pos = [screen_width // 2, screen_height // 2]
    ball_radius = 20
    ball_speed = [0.5, 0.5]

    # Create the screen
    screen = pygame.display.set_mode((screen_width, screen_height))
    pygame.display.set_caption("Simple Ball Animation")

    # Clock object to control the frame rate
    clock = pygame.time.Clock()

    # Main loop
    while True:
        # Event handling
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()

        # Update ball position
        ball_pos[0] += ball_speed[0]
        ball_pos[1] += ball_speed[1]

        # Check for collision with walls and bounce
        if ball_pos[0] - ball_radius < 0 or ball_pos[0] + ball_radius > screen_width:
            ball_speed[0] = -ball_speed[0]
        if ball_pos[1] - ball_radius < 0 or ball_pos[1] + ball_radius > screen_height:
            ball_speed[1] = -ball_speed[1]

        # Clear the screen``
        screen.fill(black)

        # Draw the ball
        color = (0, 205, 255) # Define the color green
        pygame.draw.circle(screen, color, ball_pos, ball_radius)

        # Update the display
        pygame.display.flip()

        # Cap the frame rate
        clock.tick(600)

if __name__ == "__main__":
    main()