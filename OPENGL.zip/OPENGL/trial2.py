import pygame
from OpenGL.GL import *
from OpenGL.GLU import *

def draw_triangle_fan():
    p1 = (0, 1)
    p2 = (1, 2)
    p3 = (2, 1)
    p4 = (2, 0)
    p5 = (1, -1)
    p6 = (0, 0)

    glBegin(GL_TRIANGLE_FAN)
    glVertex2iv(p1)
    glVertex2iv(p2)
    glVertex2iv(p3)
    glVertex2iv(p4)
    glVertex2iv(p5)
    glVertex2iv(p6)
    glEnd()

def main():
    pygame.init()
    display = (800, 600)
    pygame.display.set_mode(display, pygame.OPENGL | pygame.DOUBLEBUF)
    glClearColor(0.0, 0.0, 0.0, 1.0)
    glMatrixMode(GL_PROJECTION)
    glLoadIdentity()
    gluOrtho2D(-3.0, 3.0, -3.0, 3.0)

    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                quit()

        glClear(GL_COLOR_BUFFER_BIT)
        glColor3f(1.0, 1.0, 0.0)  # Yellow color
        draw_triangle_fan()
        pygame.display.flip()

if __name__ == "__main__":
    main()
