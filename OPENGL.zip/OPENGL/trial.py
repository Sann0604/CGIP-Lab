import pygame
from pygame.locals import *
from OpenGL.GL import *
from OpenGL.GLU import *

# Function to initialize the OpenGL context
def init_gl():
    glClearColor(0.0, 0.0, 0.0, 1.0)  # Set the background color to black
    glClearDepth(1.0)                 # Set the depth buffer
    glEnable(GL_DEPTH_TEST)           # Enable depth testing
    glDepthFunc(GL_LEQUAL)            # Type of depth test
    glShadeModel(GL_SMOOTH)           # Enable smooth shading

    # Set up the perspective view
    glMatrixMode(GL_PROJECTION)
    gluPerspective(45.0, 1.0, 0.1, 50.0)
    glMatrixMode(GL_MODELVIEW)
    glLoadIdentity()

# Function to draw a polygon
def draw_polygon():
    glBegin(GL_POLYGON)             # Start drawing a polygon
    glColor3f(1.0, 0.0, 0.0)        # Set the color to red
    
    glVertex3f(1.0, 1.0, 0.0)       # Top right vertex
    glVertex3f(-1.0, 1.0, 0.0)      # Top left vertex
    glVertex3f(-1.0, -1.0, 0.0)     # Bottom left vertex
    glVertex3f(1.0, -1.0, 0.0)      # Bottom right vertex
    
    glEnd()                         # End drawing the polygon

def main():
    pygame.init()
    display = (800, 600)
    pygame.display.set_mode(display, DOUBLEBUF | OPENGL)
    init_gl()
    glTranslatef(0.0, 0.0, -5.0)    # Move the polygon away from the camera

    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                quit()

        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT)  # Clear the screen and depth buffer
        draw_polygon()                                      # Draw the polygon
        pygame.display.flip()                               # Swap the front and back buffers
        pygame.time.wait(10)                                # Wait a bit to control the frame rate

if __name__ == "__main__":
    main()
