import pygame
import sys
import copy
import random

def main():
    # Initialize Pygame
    pygame.init()
        
    # Screen dimensions
    screen_width = 800
    screen_height = 600

    # Colors
    colors = [(255, 0, 0), (0, 25, 0), (0, 0, 255)]

    # Ball properties
    balls = [
        {"pos": [screen_width // 2, screen_height // 2], "radius": 2, "speed": [random.uniform(-10, 10), random.uniform(-10, 10)], "color": colors[0]},
    ]

    # Create the screen
    screen = pygame.display.set_mode((screen_width, screen_height))

    # Clock object to control the frame rate
    clock = pygame.time.Clock()

    # Main loop
    while True:
        # Event handling
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_d:  # If the "D" key is pressed
                    new_balls = [copy.deepcopy(ball) for ball in balls]
                    for new_ball in new_balls:
                        new_ball["speed"] = [random.uniform(-10, 10), random.uniform(-10, 10)]  # Assign a random speed
                        new_ball["color"] = random.choice(colors)  # Change the color
                    balls.extend(new_balls[:max(0, 100000 - len(balls))])  # Add new balls to the list

        # Update ball positions and check for collision with walls
        for ball in balls:
            ball["pos"][0] += ball["speed"][0]
            ball["pos"][1] += ball["speed"][1]

            if ball["pos"][0] - ball["radius"] < 0 or ball["pos"][0] + ball["radius"] > screen_width:
                ball["speed"][0] = -ball["speed"][0]
            if ball["pos"][1] - ball["radius"] < 0 or ball["pos"][1] + ball["radius"] > screen_height:
                ball["speed"][1] = -ball["speed"][1]

        # Clear the screen
        screen.fill((0, 0, 0))

        # Draw the balls
        for ball in balls:
            pygame.draw.circle(screen, ball["color"], [int(x) for x in ball["pos"]], ball["radius"])

        # Update the display
        pygame.display.flip()

        # Cap the frame rate
        clock.tick(600)

if __name__ == "__main__":
    main()