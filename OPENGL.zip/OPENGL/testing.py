import pygame
from pygame.locals import *
from OpenGL.GL import *
from OpenGL.GLU import *

def init_gl():
    glClearColor(0.0, 0.0, 0.0, 1.0)  # Set the background color to black
    glClearDepth(1.0)                 # Set the depth buffer
    # glEnable(GL_DEPTH_TEST)           # Enable depth testing
    # glDepthFunc(GL_LEQUAL)            # Type of depth test
    glShadeModel(GL_SMOOTH)           # Enable smooth shading

    glMatrixMode(GL_PROJECTION)
    gluPerspective(45.0, 800/600, 0.1, 50.0)  # Set up perspective
    glMatrixMode(GL_MODELVIEW)
    glLoadIdentity()

def draw_polygon():
    # Vertices of the polygon (scaled to fit within view)
    p1 = (0, 0)
    p2 = (1, 2)
    p3 = (2, 1)
    p4 = (2, 0)
    p5 = (1, -1)
    p6 = (-1, 0)

    glBegin(GL_POLYGON)                # Start drawing a polygon
    glColor3f(1.0, 0.0, 0.0)           # Set color to red
    glVertex2iv(p1)                    # First vertex
    glVertex2iv(p2)                    # Second vertex
    glVertex2iv(p3)                    # Third vertex
    glVertex2iv(p4)                    # Fourth vertex
    glVertex2iv(p5)                    # Fifth vertex
    glVertex2iv(p6)                    # Sixth vertex
    glEnd()                            # End drawing the polygon

def main():
    pygame.init()
    display = (800, 600)
    pygame.display.set_mode(display, DOUBLEBUF | OPENGL)
    init_gl()
    glTranslatef(0.0, 0.0, -5.0)  # Move the polygon away from the camera

    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                quit()

        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT)  # Clear screen and depth buffer
        draw_polygon()                                      # Draw the polygon
        pygame.display.flip()                               # Swap the front and back buffers
        pygame.time.wait(10)                                # Wait a bit to control the frame rate

if __name__ == "__main__":
    main()
