from django.contrib import admin
from .models import Author, Genre, Book

@admin.register(Author)
class AuthorAdmin(admin.ModelAdmin):
    list_display = ('last_name', 'first_name', 'date_of_birth')
    search_fields = ('last_name', 'first_name')
    list_filter = ('date_of_birth',)
    ordering = ['last_name', 'first_name']

@admin.register(Genre)
class GenreAdmin(admin.ModelAdmin):
    list_display = ('name',)
    search_fields = ('name',)

@admin.register(Book)
class BookAdmin(admin.ModelAdmin):
    list_display = ('title', 'author', 'isbn', 'display_genre')
    search_fields = ('title', 'author__last_name', 'isbn')
    list_filter = ('genre', 'author')
    ordering = ['title', 'author']

    def display_genre(self, obj):
        return ', '.join([genre.name for genre in obj.genre.all()])
    display_genre.short_description = 'Genre'
