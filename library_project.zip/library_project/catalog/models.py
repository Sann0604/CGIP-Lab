from django.db import models
from django.urls import reverse

class Genre(models.Model):
    name = models.CharField(
        max_length=200,
        help_text="Enter a book genre (e.g. Science Fiction)",
        unique=True,
        db_column='genre_name',
        verbose_name='Genre Name'
    )
    description = models.TextField(blank=True, null=True, help_text="Description of the genre")

    def __str__(self):
        return self.name

class Author(models.Model):
    first_name = models.CharField(max_length=100, verbose_name='First Name')
    last_name = models.CharField(max_length=100, verbose_name='Last Name')
    date_of_birth = models.DateField(null=True, blank=True, verbose_name='Date of Birth')

    class Meta:
        ordering = ['last_name', 'first_name']

    def __str__(self):
        return f'{self.last_name}, {self.first_name}'

class Book(models.Model):
    title = models.CharField(max_length=200, verbose_name='Title')
    author = models.ForeignKey(Author, on_delete=models.SET_NULL, null=True, verbose_name='Author')
    summary = models.TextField(max_length=1000, help_text="Enter a brief description of the book")
    isbn = models.CharField('ISBN', max_length=13, unique=True, help_text='13 Character ISBN number')
    genre = models.ManyToManyField(Genre, help_text="Select a genre for this book")
    publish_date = models.DateField(blank=True, null=True, verbose_name='Publish Date')
    default_summary = "No summary available"

    def __str__(self):
        return self.title

    def get_absolute_url(self):
        return reverse('book-detail', args=[str(self.id)])
