from django.shortcuts import render
from .models import Book, Author, Genre
from django.contrib.auth.models import User

def index(request):
    num_books = Book.objects.all().count()
    num_authors = Author.objects.count()
    users = User.objects.all()

    return render(
        request,
        'index.html',
        context={'num_books': num_books, 'num_authors': num_authors, 'users': users},
    )

def book_detail_view(request, pk):
    book = Book.objects.get(pk=pk)
    return render(request, 'book_detail.html', context={'book': book})
