from django.urls import path
from . import views

urlpatterns = [
    path('', views.index, name='index'),  # Maps the root URL to the index view
    path('register/', views.register_student, name='register_student'),  # URL for registering students
    path('search/', views.search_student, name='search_student'),  
    path('student_list/', views.student_list, name='student_list'),
]
