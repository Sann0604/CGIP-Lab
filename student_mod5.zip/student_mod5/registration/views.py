from django.shortcuts import render, get_object_or_404
from django.http import JsonResponse
from .models import Student, Course, Enrollment
from .forms import EnrollmentForm, StudentSearchForm

def index(request):
    students = Student.objects.all()  # Fetch all students
    form = EnrollmentForm()  # Instantiate the form
    return render(request, 'registration/index.html', {'students': students, 'form': form})
def register_student(request):
    if request.method == 'POST':
        form = EnrollmentForm(request.POST)
        if form.is_valid():
            student = form.cleaned_data['student']
            course = form.cleaned_data['course']
            
            # Check if the student is already enrolled in this course
            if Enrollment.objects.filter(student=student, course=course).exists():
                # Return JSON response indicating duplicate enrollment
                return JsonResponse({'error': 'Student is already enrolled in this course.'})
            
            # Create a new enrollment
            Enrollment.objects.create(student=student, course=course)
            
            # Return JSON response indicating success
            return JsonResponse({'success': 'Student enrolled successfully.'})
        else:
            # Return JSON response with form errors
            return JsonResponse({'error': form.errors})
    
    else:
        # Handle GET request if needed
        form = EnrollmentForm()
        return render(request, 'registration/register.html', {'form': form})


def search_student(request):
    if request.method == 'GET' and 'student_name' in request.GET:
        student_name = request.GET.get('student_name', None)
        if student_name:
            students = Student.objects.filter(name__icontains=student_name)
            data = {
                'students': [{
                    'name': student.name,
                    'enrollments': [{'course_name': enrollment.course.name} for enrollment in student.enrollment_set.all()]
                } for student in students]
            }
            return JsonResponse(data)
        else:
            return JsonResponse({'students': []})
    return JsonResponse({'error': 'Invalid request'})

def student_list(request):
    students = Student.objects.all()
    return render(request, 'student_list.html', {'students': students})

def search_results(request):
    if request.method == 'GET':
        student_name = request.GET.get('student_name', '')
        student = Student.objects.filter(name__icontains=student_name).first()
        if student:
            courses = student.enrollment_set.all()
            courses_list = [{'name': enrollment.course.name, 'description': enrollment.course.description} for enrollment in courses]
            return JsonResponse({'courses': courses_list})
        return JsonResponse({'courses': []})

def home(request):
    return render(request, 'home.html')