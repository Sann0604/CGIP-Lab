from django import forms
from .models import Student, Course, Enrollment

class EnrollmentForm(forms.ModelForm):
    class Meta:
        model = Enrollment
        fields = ['student', 'course']

class StudentSearchForm(forms.Form):
    student_name = forms.CharField(label='Student Name', max_length=100)
