from django.contrib import admin
from .models import Student, Course, Enrollment

class EnrollmentAdmin(admin.ModelAdmin):
    list_display = ('student', 'course_name')  # Define fields to display in list view

    def course_name(self, obj):
        return obj.course.name

admin.site.register(Student)
admin.site.register(Course)
admin.site.register(Enrollment, EnrollmentAdmin)
