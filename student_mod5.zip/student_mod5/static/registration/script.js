$(document).ready(function() {
    $('#registrationForm').on('submit', function(event) {
        event.preventDefault();
        $.ajax({
            url: '{% url "register_student" %}',
            type: 'POST',
            data: $(this).serialize(),
            success: function(response) {
                if (response.success) {
                    alert('Student registered successfully!');
                } else {
                    alert('Registration failed. Please try again.');
                }
            }
        });
    });

    $('#searchForm').on('submit', function(event) {
        event.preventDefault();
        $.ajax({
            url: '{% url "search_results" %}',
            type: 'GET',
            data: $(this).serialize(),
            success: function(response) {
                $('#searchResults').empty();
                if (response.courses.length > 0) {
                    response.courses.forEach(function(course) {
                        $('#searchResults').append('<p>' + course.name + ': ' + course.description + '</p>');
                    });
                } else {
                    $('#searchResults').append('<p>No courses found for the given student.</p>');
                }
            }
        });
    });
});
