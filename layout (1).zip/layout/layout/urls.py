from django.contrib import admin
from django.urls import path
from webpage.views import home, aboutus, contactus
urlpatterns = [
path('admin/', admin.site.urls),
path('home/', home),
path('aboutus/', aboutus),
path('contactus/', contactus),
path('', home), # Redirect root URL to home
]