# courseapp/views.py
from django.shortcuts import render, redirect, get_object_or_404
from .models import Student, Course, Project
from .forms import CourseForm, ProjectForm, StudentForm

def home(request):
    students = Student.objects.all()
    courses = Course.objects.all()
    projects = Project.objects.all()
    return render(request, 'courseapp/home.html', {'students': students, 'courses': courses, 'projects': projects})

def register_student(request):
    if request.method == 'POST':
        form = StudentForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('home')
    else:
        form = StudentForm()
    return render(request, 'courseapp/register_student.html', {'form': form})

def add_course(request):
    if request.method == 'POST':
        form = CourseForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('home')
    else:
        form = CourseForm()
    return render(request, 'courseapp/add_course.html', {'form': form})

def add_project(request):
    if request.method == 'POST':
        form = ProjectForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('home')
    else:
        form = ProjectForm()
    return render(request, 'courseapp/add_project.html', {'form': form})

def course_student_list(request, course_id):
    course = get_object_or_404(Course, id=course_id)
    students = course.students.all()
    return render(request, 'courseapp/course_student_list.html', {'course': course, 'students': students})

def project_detail(request, pk):
    project = get_object_or_404(Project, pk=pk)
    context = {
        'project': project,
    }
    return render(request, 'courseapp/project_detail.html', context)
